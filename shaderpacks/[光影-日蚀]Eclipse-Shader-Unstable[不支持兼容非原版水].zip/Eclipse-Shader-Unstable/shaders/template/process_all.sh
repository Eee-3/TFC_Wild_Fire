iProperties --properties-output "../" --glsl-output "../lib/"
PAUSE